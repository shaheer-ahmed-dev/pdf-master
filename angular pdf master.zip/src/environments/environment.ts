export const environment = {
    production: false,
    supabaseUrl: 'https://nvavawqwasqoushxsfxl.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im52YXZhd3F3YXNxb3VzaHhzZnhsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDczMDgwMDIsImV4cCI6MjAyMjg4NDAwMn0.yzT-VWasbfxSCXGF-C_TOWiiyVs6Sbob9yJEvcKWp0g',
}