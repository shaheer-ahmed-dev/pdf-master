import { KeyToTitleCasePipe } from './key-to-title-case.pipe';

describe('KeyToTitleCasePipe', () => {
  it('create an instance', () => {
    const pipe = new KeyToTitleCasePipe();
    expect(pipe).toBeTruthy();
  });
});
