export class Assets{
    static readonly baseUrl = './../../../assets/icons/';
    static readonly logo = Assets.baseUrl+'logo.png';
}