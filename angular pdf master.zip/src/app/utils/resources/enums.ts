export class enums{
    casualLeave = "Casual Leave";
    sickLeave= "Sick Leave"
}